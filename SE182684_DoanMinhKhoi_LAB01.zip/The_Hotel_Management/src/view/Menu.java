/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author PC
 */
public class Menu {
    public static void displayMenu() {
        System.out.println("=======Hotel Management System=======");
        System.out.println("1. Add new hotel");
        System.out.println("2. Check existing hotel");
        System.out.println("3. Update hotel information");
        System.out.println("4. Delete hotel");
        System.out.println("5. Search hotel");
        System.out.println("6. Display hotel list");
        System.out.println("7. Exit");
        System.out.println("=====================================");
    }
}
