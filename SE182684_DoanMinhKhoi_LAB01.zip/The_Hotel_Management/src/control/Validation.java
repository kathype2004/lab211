
package control;

import java.util.ArrayList;
import java.util.Scanner;
import model.Hotel;

/**
 * @author PC
 */
public class Validation {
    private final Scanner sc;

    public Validation() {
       sc = new Scanner(System.in);
    }
    
    /**
     * check input yes no 
     */
    public boolean checkInputYN(String mess) {
        System.out.print(mess);
        while(true) {
            String input = sc.nextLine();
            
            if(input.equalsIgnoreCase("Y")) return true;
            
            else if(input.equalsIgnoreCase("N")) return false;
            
            else {
                System.err.println("Please input y/Y or n/N.");
                System.out.print("Enter again: ");
            }
        }
    }
    
    /**
     * check input with min and max  
     */
    public int inputInt(String mess, int min, int max) {
        System.out.print(mess);
        while(true) {
            String input = sc.nextLine();
            
            try {
                int number = Integer.parseInt(input);
                
                //check max min
                if(number < min || max < number) {
                    System.err.print("Please input between from " + min + " to " + max + " please : ");
                    continue;
                }
                return number;
            }catch(Exception e) {
                System.err.print("Please input an integer number: ");
            }
        }
    }
    
    /**
     * input can not blank
     */
    public String nonBlank(String mess) {
        String input = "";
        do {
            System.out.print(mess);
            input = sc.nextLine();
            if(input.trim().isEmpty())  {System.out.println("Data can not empty");}
        }while(input.trim().isEmpty());
        return input;
    }
    
    /** 
     * check format data
     */
    public String formatData(String mess, String pattern) {
        String result = "";
        do {
            System.out.print(mess);
            result = sc.nextLine().toUpperCase();
            if(!result.matches(pattern)) {
                System.out.println("Wrong format");
            }
        }while(!result.matches(pattern));
        return result;
    }
    
    
    /**
     * compare hotel_id in array to hotel 
     */
    public boolean checkDuplicateID(ArrayList<Hotel> arrayHotel, String hotel_Id) {
        for(Hotel i : arrayHotel) {
            if(i.getHotelId().equalsIgnoreCase(hotel_Id)) {return true;}
        }
        return false;
    }
    
    
    /**
     * input id, check format and check duplicate
     */
    public String getHotelId(String mess) {
        String id = formatData(mess, "H\\d{2}");
        return id.toUpperCase();
    }
    
    /**
     * return format true when have data input from user
     */
    public String formatAdress(String s) {
        String[] tokens = s.trim().split("\\s+");
        String result = "";
        for(String i : tokens) {
            result += " " + i.substring(0, 1).toUpperCase() + i.substring(1).toLowerCase();  
        }
        return result.trim();
    }
    
    /**
     * input address
     */
    public String HotelAddress(String input1, String input2, String input3, String input4) {
        System.out.println("Address Hotel include: ");
        
        String result1 = formatAdress(nonBlank(input1));
        String result2 = nonBlank(input2).trim().toUpperCase();
        if(result2.endsWith("Ward"))    {
            result2 = formatAdress(result2);}
        
        else    {
            result2 = "Ward " + formatAdress(result2);}
        
        String result3 = nonBlank(input3).trim().toUpperCase();
        if(result3.endsWith("District"))    {
            result3 = formatAdress(result3);}
        else    {
            result3 = formatAdress(result3) + " Disstrict";
        }
        
        String result4 = nonBlank(input4).trim().toUpperCase();
        if(result4.contains("HO CHI MINH") ||
            result4.contains("HA NOI") ||
            result4.contains("HAI PHONG") ||
            result4.contains("DA NANG") || 
            result4.contains("CAN THO"))
                {result4 = formatAdress(result4) + " City";}
        
        else    {
            result4 = formatAdress(result4) + " Province";
        }
        
        return String.format("%s, %s, %s, %s", result1, result2, result3, result4);
    }
    
    //use for update Phone
    public boolean checkformatPhone(String input, String pattern) {
        String result = input;
        if(!result.matches(pattern)) {
            System.err.println("Wrong format");
            return false;
        }
        return true;
    }
    
    //use for update Rate
    public boolean checkMinMax(int input, int min, int max) {
        int result = input;
        if(result < min || max < result) {
            System.err.print("Please input between from " + min + "to " + max + "please : ");
            return false;
        }
        return true;
    }
    
    
}
