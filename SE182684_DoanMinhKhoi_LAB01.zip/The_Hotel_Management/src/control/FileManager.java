/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import model.Hotel;

/**
 *
 * @author PC
 */
public class FileManager {
    /**
     * write data to file
     */
    public boolean writeToFile(String fileName, ArrayList<Hotel> arrayHotel) {
        try {
            
            File f = new File(fileName);
            FileOutputStream fos = new FileOutputStream(f);
            ObjectOutput o = new ObjectOutputStream(fos);        
            for(Hotel i : arrayHotel) {
                o.writeObject(i);
            }
            
            fos.close();
            o.close();
            System.err.println("Save data sucessfully!!");
            return true;
            
        }catch(Exception e) {
            System.err.println("Error write");
            return false;
        }
    }
    /**
     * read file
     */
    public boolean readFromFile(String fileName, ArrayList<Hotel> arrayHotel) {
        try {
            // check file exist
            File f = new File(fileName);
            if(!f.exists()) {return false;}
            
            FileInputStream fis = new FileInputStream(f);
            ObjectInputStream oi = new ObjectInputStream(fis);
            
            if(f.length() == 0) {System.err.println("File is Empty!");}
            
            boolean check = true;   //use to break loop
            do {
                try {
                    Hotel h = (Hotel) oi.readObject();
                    arrayHotel.add(h);
                }catch(Exception e) {
                    check = false;}
            }while(check);
            
            fis.close();
            oi.close();
            
        }catch(Exception e) {
            System.err.println("Error read");
            return false;
        }
        return true;
    }
}
