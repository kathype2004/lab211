/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.io.EOFException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import model.Hotel;


/**
 *
 * @author PC
 */
public class HotelManagement {
    
    private ArrayList<Hotel> arrayHotel = new ArrayList<>();;
    private FileManager fm;
    private Validation va;


    public HotelManagement() throws EOFException {        
        
        va = new Validation();
        fm = new FileManager();

        fm.readFromFile("Hotel.dat", arrayHotel);

    }
    
/**
 * get id for finding by id
 */
    public Hotel getId(ArrayList<Hotel> arrayHotel, String Id) {
        Hotel result = null;
        for(Hotel i : arrayHotel) {
            if(i.getHotelId().equalsIgnoreCase(Id)) {
                result = i;
            }
        }
        return result;
    }
    
/**
 * function 1 add new hotel
 */
    public void addHotel() {
        boolean creat = false;
        while(!creat) {
            String hotel_Id = va.getHotelId("Enter Hotel ID(Hxx): ");
            String hotel_Name = va.nonBlank("Enter Hotel Name: ");
            int room_Avaiable = va.inputInt("Enter avaiable room: ", 0, Integer.MAX_VALUE);
            String hotel_Adress = va.HotelAddress("Enter No. and Street Name: ",
                                                  "Enter Ward: ", 
                                                  "Enter District: ", 
                                                  "Enter Province/City: ");
            String hotel_Phone = va.formatData("Enter hotel phone number(09xxxxxxxx): ", "09\\d{8}");
            int hotel_Rate = va.inputInt("Enter rating (0-9): ", 0, 9);
            
            if(va.checkDuplicateID(arrayHotel, hotel_Id)) {
                System.err.println("Save data fail!!");
            }
            else {
                arrayHotel.add(new Hotel(hotel_Id, hotel_Name, room_Avaiable, hotel_Adress, hotel_Phone, hotel_Rate));
                fm.writeToFile("Hotel.dat", arrayHotel);
            }
            if(va.checkInputYN("Do you want to add one more hotel?(Y or y/N or n): ")) {
               creat = false;
            } else {
                creat = true;
            }
        }
    }
    
    /**
     * function 2 Check exist
     */
    public void checkExistHotel() {
        String hotel_Id = "";
        boolean choose = false;
        while(!choose)  {
            hotel_Id = va.nonBlank("Enter Hotel ID that you want to check: ");
            if(va.checkDuplicateID(arrayHotel, hotel_Id)) {
                System.err.println("Exist Hotel");
                display_A_Hotel(getId(arrayHotel, hotel_Id));
            }
            else    {System.err.println("No Hotel Found!");}
            
            if(va.checkInputYN("Do you want to back menu?(Y or y/N or n): ")) {
               choose = true;
            } else {
                choose = false;
            }
        }
    }
    
    /**
     * function 3 update information hotel
     */
    public void updateHotel() {
        Scanner sc = new Scanner(System.in);
        String id = va.nonBlank("Enter hotel ID you want to update: ");
        
        if (!va.checkDuplicateID(arrayHotel, id)) {
            System.out.println("Hotel does not exist!!"); }
        
        else {
            Hotel hotel = getId(arrayHotel, id);
            display_A_Hotel(hotel);
            boolean check = false;
            
            for(int i=0;i<arrayHotel.size();i++) {
                if(arrayHotel.get(i).getHotelId().equalsIgnoreCase(id)) {
                    //name
                    System.out.print("Enter new Hotel Name: ");
                    String newHotelName = sc.nextLine().trim();
                    if(!newHotelName.isEmpty()) {
                        arrayHotel.get(i).setHotelName(newHotelName);
                    } else if(newHotelName.isEmpty()) {
                        arrayHotel.get(i).getHotelName();
                    }

                    //room avaiable
                    System.out.print("Enter new Room Avaiable: ");
                    do {
                        int newAvaiableRoom = -1;
                        try {
                            String input = sc.nextLine();
                            newAvaiableRoom = Integer.parseInt(input);
                        }catch(Exception e) {newAvaiableRoom = -1;}
                        if(newAvaiableRoom != -1) {
                            if(va.checkMinMax(newAvaiableRoom, 0, Integer.MAX_VALUE)) {
                                arrayHotel.get(i).setRoomAvailable(newAvaiableRoom);
                                check = true;
                            }
                        } else if(newAvaiableRoom == -1) {
                            arrayHotel.get(i).getRoomAvailable();
                            check = true;
                        }

                    }while(!check);

                    //address
                    System.out.print("Enter new Address: ");
                    String newAddress = sc.nextLine().trim();
                    if(!newAddress.isEmpty()) {
                        arrayHotel.get(i).setHotelAddress(newAddress);
                    } else if(newAddress.isEmpty()) {
                        arrayHotel.get(i).getHotelAddress();
                    }

                    //phone
                    check = false;
                    do {
                        System.out.print("Enter new Phone(09xxxxxxxx): ");
                        String newPhone = sc.nextLine().trim();
                        if(!newPhone.isEmpty()) {
                            if(va.checkformatPhone(newPhone, "09\\d{8}")) {
                                arrayHotel.get(i).setHotelPhone(newPhone);
                                check = true;
                            }   else {
                                check = false;
                            }
                        } else if(newPhone.isEmpty()) {
                            arrayHotel.get(i).getHotelPhone();
                            check = true;
                        }
                    }while(!check);

                    //rate
                    check = false;  
                    System.out.print("Enter rating (0-9): ");
                    do {
                        int newRate = -1;
                        try {
                            String input = sc.nextLine();
                            newRate = Integer.parseInt(input);
                        } catch(Exception e) {
                            newRate = -1;
                        }
                        if(!Integer.toString(newRate).isEmpty() && newRate != -1) {
                           if(va.checkMinMax(newRate,0,9)) {
                                arrayHotel.get(i).setHotelRate(newRate);
                                check = true; 
                           }
                        } else if(newRate == -1) {
                           arrayHotel.get(i).getHotelRate();
                           check = true;
                        }
                    }while(!check);
                    //write file
                    fm.writeToFile("Hotel.dat", arrayHotel);
                    hotel = getId(arrayHotel, id);  //print result
                    display_A_Hotel(hotel);
                    return;
                }
            }
        }
    }
    
    /**
     * function 4 delete
     */
    public void deleteHotel() {
        String id = va.nonBlank("Enter id hotel that you want to delete: ");
        
        if(va.checkDuplicateID(arrayHotel, id)) {
            Hotel show = getId(arrayHotel, id);
            display_A_Hotel(show);
            boolean choice = va.checkInputYN("Do you really want to delete this hotel(Y or y/N or n): ");
            if(choice) {
                arrayHotel.remove(getId(arrayHotel, id));
                fm.writeToFile("Hotel.dat", arrayHotel);
                System.out.println("Delete hotel success");
                
            }   else    {System.out.println("Delete hotel fail");}
            
        }   else {System.out.println("Hotel does not exist!");}
    }
    
    /**
     * function 5 search hotel
     */
    public void searchHotel() {
        System.out.println("=======Hotel Search System=======");
        System.out.println("1. Search by ID");
        System.out.println("2. Search by Name");
        System.out.println("3. Exit to menu");
        int choice = va.inputInt("Enter choice (1-3): ", 1, 3);
        switch(choice) {
            case 1:
                int countId = 0;
                String id = va.nonBlank("Enter ID Hotel: ");
                Collections.sort(arrayHotel, (Hotel hotel1, Hotel hotel2) -> hotel1.getHotelId().compareTo(hotel2.getHotelId()));
                for(Hotel i : arrayHotel) {
                    if(i.getHotelId().contains(id.toUpperCase())) {
                        Hotel found1 = i;
                        display_A_Hotel(found1);
                        countId++;
                    }
                    
                }
                if(countId == 0)
                {System.out.println("Hotel does not exist!");}
                
                break;
            case 2:
                int countName = 0;
                String name = va.nonBlank("Enter Name Hotel: ");
                
                for(Hotel i : arrayHotel) {
                    if(i.getHotelName().contains(name)) {
                        Hotel found1 = i;
                        display_A_Hotel(found1);
                        countName++;
                    }
                    
                }
                if(countName == 0)
                {System.out.println("Hotel does not exist!");}
                break;
            default:
                break;
        }
    }
    
    /**
     * function 6 arrange and show up
     */
    public void display_Hotel_List() {
        Collections.sort(arrayHotel, (Hotel hotel1, Hotel hotel2) -> -hotel1.getHotelName().compareTo(hotel2.getHotelName()));
        if(arrayHotel.isEmpty()) {
            System.err.println("List is empty!");
            return;
        }
        
        System.out.println("==============================================================================================================");
        
        for(Hotel i : arrayHotel) {
            System.out.println("Hotel_ID: " + i.getHotelId());
            System.out.println("Hotel_Name: " + i.getHotelName());
            System.out.println("Hotel_Room_Available: " + i.getRoomAvailable());
            System.out.println("Hotel_Address: " + i.getHotelAddress());
            System.out.println("Hotel_Phone: " + i.getHotelPhone());
            System.out.println("Hotel_Rating: " + i.getHotelRate());
        System.out.println("==============================================================================================================");
        
    }
    
    }
    
    @SuppressWarnings("empty-statement")    //skip warning empty-statement
    public void display_A_Hotel(Hotel object) {
        System.out.println("==============================================================================================================");
        System.out.println("Hotel_ID: " + object.getHotelId());
            System.out.println("Hotel_Name: " + object.getHotelName());
            System.out.println("Hotel_Room_Available: " + object.getRoomAvailable());
            System.out.println("Hotel_Address: " + object.getHotelAddress());
            System.out.println("Hotel_Phone: " + object.getHotelPhone());
            System.out.println("Hotel_Rating: " + object.getHotelRate());
        System.out.println("==============================================================================================================");
    }
}
