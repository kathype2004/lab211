/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author PC
 */
public class Hotel implements Serializable{
    private String hotelId;
    private String hotelName;
    private int roomAvailable;
    private String hotelPhone;
    private String hotelAddress;
    private int hotelRate;

    /**
      constructor with field
     * @param hotelId
     * @param hotelName
     * @param roomAvailable
     * @param hotelPhone
     * @param hotelAddress
     * @param hotelRate
    **/
    public Hotel(String hotelId, String hotelName, int roomAvailable, String hotelAddress, String hotelPhone, int hotelRate) {
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.roomAvailable = roomAvailable;
        this.hotelAddress = hotelAddress;
        this.hotelPhone = hotelPhone;
        this.hotelRate = hotelRate;
    }

    public String getHotelId() {
        return hotelId;
    }

    public void setHotelId(String hotelId) {
        this.hotelId = hotelId;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public int getRoomAvailable() {
        return roomAvailable;
    }

    public void setRoomAvailable(int roomAvailable) {
        this.roomAvailable = roomAvailable;
    }

    public String getHotelPhone() {
        return hotelPhone;
    }

    public void setHotelPhone(String hotelPhone) {
        this.hotelPhone = hotelPhone;
    }

    public String getHotelAddress() {
        return hotelAddress;
    }

    public void setHotelAddress(String hotelAddress) {
        this.hotelAddress = hotelAddress;
    }

    public int getHotelRate() {
        return hotelRate;
    }

    public void setHotelRate(int hotelRate) {
        this.hotelRate = hotelRate;
    }
    
    
    @Override
    public String toString() {
        return String.format("|%9s|%17s|%5d|%20s|%11s|%4d star|\n", hotelId, hotelName, roomAvailable, hotelAddress, hotelPhone, hotelRate);
    }

    
}
