/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import control.HotelManagement;
import control.Validation;
import java.io.EOFException;
import java.util.Scanner;
import static view.Menu.displayMenu;

/**
 *
 * @author SE182684_DoanMinhKhoi
 */
public class Main {
    public static void main(String[] args) throws EOFException {
        Scanner sc = new Scanner(System.in);
        HotelManagement manage = new HotelManagement();
        Validation access = new Validation();
        boolean check = false;
        do {
            displayMenu();
            int choice = access.inputInt("Enter your choice(1-7): ", 1, 7);
            
            switch(choice) {
                case 1:
                    manage.addHotel();
                    break;
                case 2:
                    manage.checkExistHotel();
                    break;     
                case 3:
                    manage.updateHotel();
                    break;
                case 4:
                    manage.deleteHotel();
                    break; 
                case 5:
                    manage.searchHotel();
                    break;
                case 6:
                    manage.display_Hotel_List();
                    break;    
                default:
                    check = true;
                    System.out.println("Exiting the program. Goodbye!");
                    break;
            }
        }while(!check);
    }
    
        
}
